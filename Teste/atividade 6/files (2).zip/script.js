const $ = s => document.querySelector(s);
const CATS = ["Manutenção", "Limpeza", "Produção", "Administrativo", "Outros"];
const COLS = [{ k: "todo", n: "A fazer" }, { k: "doing", n: "Em andamento" }, { k: "done", n: "Concluídas" }];
const ST = { todo: "A fazer", doing: "Em andamento", done: "Concluída", atrasadas: "Atrasadas" };
const hoje = () => new Date().toLocaleDateString("sv");           // AAAA-MM-DD local
const agora = () => new Date().toLocaleString("pt-BR");
const dbr = d => d ? d.split("-").reverse().join("/") : "—";
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const late = t => t.st !== "done" && t.prazo && t.prazo < hoje();

let db = (() => { try { const d = JSON.parse(localStorage.getItem("ativ_db")); if (d && d.contas) return d; } catch {} return { contas: [], resp: [], tarefas: [] }; })();
let me = null, filtro = "todas";
const save = () => localStorage.setItem("ativ_db", JSON.stringify(db));
const isAdm = () => me && me.p === "admin";
const rn = id => (db.resp.find(r => r.id === id) || {}).nome || "—";

async function hash(u, p) {
  const s = "ativ|" + u + "|" + p;
  if (window.crypto && crypto.subtle) {
    const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
    return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
  }
  return btoa(unescape(encodeURIComponent(s))); // alternativa fraca se o navegador não tiver crypto.subtle
}

/* ---------- Início e login ---------- */
(async () => {
  const dh = await hash("admin", "admin123");
  if (!db.contas.length) { db.contas.push({ u: "admin", h: dh, p: "admin" }); save(); }
  $("#dica").hidden = !db.contas.some(c => c.u === "admin" && c.h === dh);
  const c = db.contas.find(x => x.u === sessionStorage.getItem("ativ_u"));
  c ? entrar(c) : ($("#login").hidden = false);
})();

$("#fl").onsubmit = async e => {
  e.preventDefault();
  const u = $("#lu").value.trim(), h = await hash(u, $("#lp").value);
  const c = db.contas.find(x => x.u === u && x.h === h);
  if (!c) { $("#loginMsg").textContent = "Usuário ou senha inválidos."; return; }
  $("#loginMsg").textContent = ""; $("#fl").reset();
  sessionStorage.setItem("ativ_u", u); entrar(c);
};
$("#sair").onclick = () => { sessionStorage.removeItem("ativ_u"); location.reload(); };

function entrar(c) {
  me = c;
  $("#login").hidden = true; $("#app").hidden = false;
  document.body.classList.toggle("op", c.p !== "admin");
  $("#quem").textContent = c.u + " (" + (c.p === "admin" ? "Administrador" : "Operador") + ")";
  $("#fcat").innerHTML = CATS.map(x => `<option>${x}</option>`).join("");
  $("#rt").innerHTML = `<option value="">Todos os tipos</option>` + CATS.map(x => `<option>${x}</option>`).join("");
  draw();
}

/* ---------- Desenho da tela ---------- */
function card(t) {
  const i = COLS.findIndex(c => c.k === t.st);
  return `<article class="card ${t.st === "done" ? "done" : ""}"><p>${esc(t.t)}</p>
    <div class="meta"><span class="tag">${esc(t.cat)}</span><span class="tag ${late(t) ? "late" : ""}">Prazo: ${dbr(t.prazo)}</span><span class="tag">Resp.: ${esc(rn(t.resp))}</span></div>
    <div class="acts">${i > 0 ? `<button data-m="${t.id}" data-d="-1">← ${COLS[i - 1].n}</button>` : ""}${i < 2 ? `<button data-m="${t.id}" data-d="1">${COLS[i + 1].n} →</button>` : ""}<button class="del adm" data-x="${t.id}">Excluir</button></div></article>`;
}

function draw() {
  const T = db.tarefas, n = k => T.filter(t => t.st === k).length, tot = T.length || 1;
  $("#pct").textContent = Math.round(n("done") / tot * 100) + "%";
  $("#bd").style.width = n("done") / tot * 100 + "%";
  $("#bg").style.width = n("doing") / tot * 100 + "%";

  $("#chips").innerHTML = ["todas", "atrasadas", ...CATS].map(f =>
    `<button class="chip" data-f="${f}" aria-pressed="${f === filtro}">${f === "todas" ? "Todas" : f === "atrasadas" ? "Atrasadas" : f}</button>`).join("");

  const ok = t => filtro === "todas" || (filtro === "atrasadas" ? late(t) : t.cat === filtro);
  $("#board").innerHTML = COLS.map(c => {
    const L = T.filter(t => t.st === c.k && ok(t));
    return `<section class="col" style="--c:var(--${c.k})"><h2>${c.n}<span>${L.length}</span></h2>${L.map(card).join("") || '<div class="empty">Nenhuma atividade.</div>'}</section>`;
  }).join("");

  const v = $("#fresp").value;
  $("#fresp").innerHTML = `<option value="">Sem responsável</option>` + db.resp.map(r => `<option value="${r.id}">${esc(r.nome)}</option>`).join("");
  $("#fresp").value = v;

  $("#ul").innerHTML = db.resp.map(r => `<li><span>${esc(r.nome)}</span><span class="n">${T.filter(t => t.resp === r.id).length} ativ.</span><button class="del" data-r="${r.id}">Excluir</button></li>`).join("");
  $("#cl").innerHTML = db.contas.map(c => `<li><span>${esc(c.u)}</span><span class="n">${c.p === "admin" ? "Administrador" : "Operador"}</span>${c.u !== me.u ? `<button class="del" data-c="${esc(c.u)}">Excluir</button>` : ""}</li>`).join("");
}

/* ---------- Atividades ---------- */
$("#f").onsubmit = e => {
  e.preventDefault();
  const t = $("#ft").value.trim(); if (!t) return;
  db.tarefas.push({ id: uid(), t, cat: $("#fcat").value, prazo: $("#fp").value, resp: $("#fresp").value, st: "todo", criada: hoje(), fim: null, fimPor: null,
    hist: [{ em: agora(), por: me.u, de: null, para: "todo" }] });
  save(); e.target.reset(); draw();
};

$("#board").onclick = e => {
  const b = e.target.closest("button"); if (!b) return;
  const t = db.tarefas.find(x => x.id === (b.dataset.m || b.dataset.x)); if (!t) return;
  if (b.dataset.x) { if (isAdm() && confirm("Excluir esta atividade?")) { db.tarefas = db.tarefas.filter(x => x !== t); save(); draw(); } return; }
  const para = COLS[COLS.findIndex(c => c.k === t.st) + +b.dataset.d].k;
  t.hist.push({ em: agora(), por: me.u, de: t.st, para });          // registra QUEM movimentou
  t.st = para;
  t.fim = para === "done" ? hoje() : null; t.fimPor = para === "done" ? me.u : null;
  save(); draw();
};

$("#chips").onclick = e => { const b = e.target.closest("button"); if (b) { filtro = b.dataset.f; draw(); } };
$("#limpa").onclick = () => { if (isAdm() && confirm("Apagar todas as atividades concluídas? Elas sairão dos relatórios.")) { db.tarefas = db.tarefas.filter(t => t.st !== "done"); save(); draw(); } };

/* ---------- Responsáveis e contas (administrador) ---------- */
$("#fu").onsubmit = e => {
  e.preventDefault(); if (!isAdm()) return;
  const nome = $("#un").value.trim();
  if (db.resp.some(r => r.nome.toLowerCase() === nome.toLowerCase())) { alert("Responsável já cadastrado."); return; }
  db.resp.push({ id: uid(), nome }); save(); e.target.reset(); draw();
};
$("#ul").onclick = e => {
  const id = e.target.dataset.r; if (!id || !isAdm()) return;
  if (db.tarefas.some(t => t.resp === id)) { alert("Este responsável possui atividades e não pode ser excluído."); return; }
  db.resp = db.resp.filter(r => r.id !== id); save(); draw();
};

$("#fc").onsubmit = async e => {
  e.preventDefault(); if (!isAdm()) return;
  const u = $("#cu").value.trim(), p = $("#cperf").value, h = await hash(u, $("#cp").value);
  const c = db.contas.find(x => x.u === u);
  if (c) {
    if (c.p === "admin" && p !== "admin" && db.contas.filter(x => x.p === "admin").length === 1) { alert("É preciso manter ao menos um administrador."); return; }
    c.h = h; c.p = p;
  } else db.contas.push({ u, h, p });
  save(); e.target.reset(); draw();
};
$("#cl").onclick = e => {
  const u = e.target.dataset.c; if (!u || !isAdm() || !confirm("Excluir a conta " + u + "?")) return;
  db.contas = db.contas.filter(c => c.u !== u); save(); draw();
};

/* ---------- Relatório ---------- */
function gerar() {
  const tp = $("#rt").value, d = $("#rd").value, a = $("#ra").value, b = $("#rb").value, s = $("#rs").value, h = $("#rh").checked;
  const L = db.tarefas.filter(t => (!tp || t.cat === tp) && (!s || (s === "atrasadas" ? late(t) : t.st === s)) &&
    ((!d && !a) || (t[b] && (!d || t[b] >= d) && (!a || t[b] <= a))));
  const cnt = k => L.filter(t => t.st === k).length;
  const box = (n, l) => `<div class="rbox"><b>${n}</b><span>${l}</span></div>`;

  let H = `<div class="acoes"><button class="primary" id="rimp">Imprimir</button><button class="sec" id="rfech">Fechar</button></div>
    <h2>Relatório de Atividades</h2>
    <p class="rinfo">Gerado em ${agora()} por ${esc(me.u)} · Tipo: ${tp || "todos"} · ${{ criada: "Criação", prazo: "Prazo", fim: "Conclusão" }[b]}: ${d || a ? (d ? dbr(d) : "início") + " a " + (a ? dbr(a) : "sem limite") : "todo o período"} · Situação: ${s ? ST[s] : "todas"}</p>
    <div class="resumo">${box(L.length, "Total")}${box(cnt("todo"), "A fazer")}${box(cnt("doing"), "Em andamento")}${box(cnt("done"), "Concluídas")}${box(L.filter(late).length, "Atrasadas")}</div>`;

  CATS.forEach(cat => {
    const G = L.filter(t => t.cat === cat); if (!G.length) return;
    H += `<h3>${cat} (${G.length})</h3><table><thead><tr><th>Atividade</th><th>Quem fez (responsável)</th><th>Situação</th><th>Prazo</th><th>Concluída em</th><th>Última movimentação (quem / quando)</th>${h ? "<th>Histórico de quem movimentou</th>" : ""}</tr></thead><tbody>`;
    G.forEach(t => {
      const u = t.hist[t.hist.length - 1];
      H += `<tr><td>${esc(t.t)}</td><td>${esc(rn(t.resp))}</td><td>${ST[t.st]}${late(t) ? " (atrasada)" : ""}</td><td>${dbr(t.prazo)}</td><td>${t.fim ? dbr(t.fim) + " por " + esc(t.fimPor) : "—"}</td><td>${esc(u.por)} · ${u.em}</td>` +
        (h ? `<td>${t.hist.map(x => `${x.em} — ${esc(x.por)}: ${x.de ? ST[x.de] + " → " : "criou em "}${ST[x.para]}`).join("<br>")}</td>` : "") + `</tr>`;
    });
    H += `</tbody></table>`;
  });
  if (!L.length) H += `<p class="rinfo">Nenhuma atividade encontrada com esses filtros.</p>`;

  $("#relatorio").innerHTML = H; $("#relatorio").hidden = false;
  $("#rimp").onclick = () => print();
  $("#rfech").onclick = () => ($("#relatorio").hidden = true);
  $("#relatorio").scrollIntoView({ behavior: "smooth" });
}
$("#fr").onsubmit = e => { e.preventDefault(); gerar(); };
$("#rp").onclick = () => { gerar(); print(); };

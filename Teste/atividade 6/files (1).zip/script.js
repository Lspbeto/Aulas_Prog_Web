document.addEventListener("DOMContentLoaded", () => {
    const STORAGE_KEY = "users";

    const statusCard = document.getElementById("status-card");
    const statusTitle = document.getElementById("status-title");
    const statusMessage = document.getElementById("status-message");
    const registerCard = document.getElementById("register-card");
    const formTitle = document.getElementById("form-title");
    const formMessage = document.getElementById("form-message");
    const usersCard = document.getElementById("users-card");
    const userForm = document.getElementById("user-form");
    const userList = document.getElementById("user-list");
    const addMoreBtn = document.getElementById("add-more-btn");
    const clearBtn = document.getElementById("clear-btn");

    // ---------- Armazenamento ----------
    function getUsers() {
        try {
            const users = JSON.parse(localStorage.getItem(STORAGE_KEY));
            return Array.isArray(users) ? users : [];
        } catch {
            return []; // dado corrompido no localStorage
        }
    }

    function saveUsers(users) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(users));
    }

    // ---------- Senha (hash com salt, em vez de texto puro) ----------
    function toHex(buffer) {
        return Array.from(new Uint8Array(buffer))
            .map((b) => b.toString(16).padStart(2, "0"))
            .join("");
    }

    async function hashPassword(password, salt) {
        const data = new TextEncoder().encode(salt + password);
        const digest = await crypto.subtle.digest("SHA-256", data);
        return toHex(digest);
    }

    function newSalt() {
        return toHex(crypto.getRandomValues(new Uint8Array(16)));
    }

    // ---------- Interface ----------
    function showMessage(text) {
        formMessage.textContent = text;
    }

    function checkInitialState() {
        const users = getUsers();
        showMessage("");

        if (users.length === 0) {
            statusTitle.textContent = "Nenhum usuário cadastrado";
            statusMessage.textContent = "É necessário cadastrar o primeiro usuário para utilizar o sistema.";
            formTitle.textContent = "Cadastrar Primeiro Usuário";

            statusCard.classList.remove("hidden");
            registerCard.classList.remove("hidden");
            usersCard.classList.add("hidden");
        } else {
            statusCard.classList.add("hidden");
            registerCard.classList.add("hidden");
            usersCard.classList.remove("hidden");
            renderUserList(users);
        }
    }

    // textContent evita injeção de HTML (XSS)
    function renderUserList(users) {
        userList.innerHTML = "";
        users.forEach((user, index) => {
            const li = document.createElement("li");

            const name = document.createElement("strong");
            name.textContent = user.username;
            if (index === 0) {
                const tag = document.createElement("span");
                tag.className = "admin-tag";
                tag.textContent = " (Primeiro Usuário / Admin)";
                name.appendChild(tag);
            }

            const email = document.createElement("span");
            email.textContent = user.email;

            li.append(name, email);
            userList.appendChild(li);
        });
    }

    // ---------- Eventos ----------
    userForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const username = document.getElementById("username").value.trim();
        const email = document.getElementById("email").value.trim().toLowerCase();
        const password = document.getElementById("password").value;

        if (!username || !email || !password) {
            showMessage("Por favor, preencha todos os campos.");
            return;
        }
        if (password.length < 6) {
            showMessage("A senha deve ter pelo menos 6 caracteres.");
            return;
        }

        const users = getUsers();
        if (users.some((u) => u.email === email)) {
            showMessage("Já existe um usuário com este e-mail.");
            return;
        }
        if (users.some((u) => u.username.toLowerCase() === username.toLowerCase())) {
            showMessage("Este nome de usuário já está em uso.");
            return;
        }

        if (!window.crypto || !crypto.subtle) {
            showMessage("Seu navegador não suporta criptografia. Abra a página via localhost ou HTTPS.");
            return;
        }

        const salt = newSalt();
        const passwordHash = await hashPassword(password, salt);

        users.push({ username, email, salt, passwordHash });
        saveUsers(users);

        userForm.reset();
        checkInitialState();
    });

    addMoreBtn.addEventListener("click", () => {
        formTitle.textContent = "Cadastrar Novo Usuário";
        showMessage("");
        registerCard.classList.toggle("hidden");
    });

    clearBtn.addEventListener("click", () => {
        if (confirm("Tem certeza que deseja apagar todos os usuários? O sistema voltará ao estado inicial.")) {
            localStorage.removeItem(STORAGE_KEY);
            checkInitialState();
        }
    });

    checkInitialState();
});

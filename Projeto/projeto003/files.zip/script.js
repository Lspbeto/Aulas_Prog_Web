/* ===== DADOS FIXOS ===== */
// As 3 etapas: k = código interno, nome = texto exibido, cor = cor da faixa da coluna
const STATUS = [
  { k: 'todo',  nome: 'A fazer',      cor: 'var(--todo)'  },
  { k: 'doing', nome: 'Em andamento', cor: 'var(--doing)' },
  { k: 'done',  nome: 'Concluídas',   cor: 'var(--done)'  }
];
const CATS = ['Todas', 'Trabalho', 'Estudo', 'Casa', 'Pessoal']; // opções do filtro

let tarefas = [];       // lista de atividades
let usuarios = [];      // lista de usuários: { id, nome }
let filtro = 'Todas';   // categoria selecionada no filtro
let editAtiv = null;    // id da atividade em edição (null = criando uma nova)
let editUser = null;    // id do usuário em edição (null = criando um novo)

/* ===== CARREGAR E SALVAR (localStorage) ===== */
function ler(chave) {                                    // lê uma lista salva no navegador
  try {
    const v = JSON.parse(localStorage.getItem(chave) || '[]'); // texto salvo -> lista
    return Array.isArray(v) ? v : [];                    // garante que é mesmo uma lista
  } catch (e) { return []; }                             // se falhar, começa vazio
}
tarefas = ler('atividades');
usuarios = ler('usuarios');

function salvar() {                                      // grava as duas listas no navegador
  try {
    localStorage.setItem('atividades', JSON.stringify(tarefas));
    localStorage.setItem('usuarios', JSON.stringify(usuarios));
  } catch (e) {}
}

/* ===== FUNÇÕES AUXILIARES ===== */
function novoId() { return Date.now() + Math.random().toString(36).slice(2, 6); } // id único em texto
function hoje() {                                        // data de hoje como "AAAA-MM-DD"
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function fmt(s) { const [y, m, d] = s.split('-'); return d + '/' + m; } // "2026-10-22" -> "22/10"
function el(tag, classe, texto) {                        // cria um elemento HTML rapidamente
  const e = document.createElement(tag);
  if (classe) e.className = classe;                      // classe CSS, se houver
  if (texto != null) e.textContent = texto;              // texto (seguro contra código malicioso)
  return e;
}
function nomeUsuario(id) {                               // devolve o nome do usuário pelo id (ou '')
  const u = usuarios.find(x => x.id === id);
  return u ? u.nome : '';
}
const $ = id => document.getElementById(id);             // atalho para buscar elementos pelo id

/* ===== USUÁRIOS: CRIAR, EDITAR, EXCLUIR ===== */
function resetUsuario() {                                // volta o formulário de usuário ao modo "criar"
  editUser = null;
  $('fu').reset();
  $('btnUsuario').textContent = 'Adicionar usuário';
  $('cancelaUsuario').hidden = true;
}
function editarUsuario(id) {                             // coloca o usuário no formulário para editar
  editUser = id;
  $('nomeUsuario').value = nomeUsuario(id);              // preenche o campo com o nome atual
  $('btnUsuario').textContent = 'Salvar usuário';
  $('cancelaUsuario').hidden = false;                    // mostra o botão Cancelar
  $('nomeUsuario').focus();
}
function apagarUsuario(id) {                             // exclui o usuário
  if (!confirm('Excluir o usuário "' + nomeUsuario(id) + '"? Suas atividades ficarão sem responsável.')) return;
  usuarios = usuarios.filter(u => u.id !== id);          // remove da lista
  tarefas.forEach(t => { if (t.resp === id) t.resp = ''; }); // atividades dele ficam sem responsável
  if (editUser === id) resetUsuario();
  salvar(); render();
}
$('fu').addEventListener('submit', e => {                // ao enviar o formulário de usuário
  e.preventDefault();                                    // impede recarregar a página
  const nome = $('nomeUsuario').value.trim();
  if (!nome) return;
  if (editUser) {                                        // modo edição: altera o nome
    const u = usuarios.find(x => x.id === editUser);
    if (u) u.nome = nome;
  } else {                                               // modo criação: adiciona à lista
    usuarios.push({ id: novoId(), nome });
  }
  resetUsuario(); salvar(); render();
});
$('cancelaUsuario').onclick = resetUsuario;              // Cancelar: desfaz a edição

/* ===== ATIVIDADES: CRIAR, EDITAR, EXCLUIR, MOVER ===== */
function resetAtiv() {                                   // volta o formulário de atividade ao modo "criar"
  editAtiv = null;
  $('f').reset();
  $('btnAtiv').textContent = 'Adicionar';
  $('cancela').hidden = true;
}
function editarAtiv(id) {                                // carrega a atividade no formulário
  const t = tarefas.find(x => x.id === id);
  if (!t) return;
  editAtiv = id;
  $('titulo').value = t.titulo;
  $('cat').value = t.cat;
  $('resp').value = t.resp || '';                        // '' = sem responsável
  $('prazo').value = t.prazo || '';
  $('btnAtiv').textContent = 'Salvar alterações';
  $('cancela').hidden = false;
  $('f').scrollIntoView({ behavior: 'smooth', block: 'center' }); // rola até o formulário
  $('titulo').focus();
}
function apagar(id) {                                    // exclui a atividade
  const t = tarefas.find(x => x.id === id);
  if (!t || !confirm('Excluir a atividade "' + t.titulo + '"?')) return;
  tarefas = tarefas.filter(x => x.id !== id);
  if (editAtiv === id) resetAtiv();
  salvar(); render();
}
function mover(id, k) {                                  // muda a etapa de uma atividade
  const t = tarefas.find(x => x.id === id);
  if (t) { t.status = k; salvar(); render(); }
}
$('f').addEventListener('submit', e => {                 // ao enviar o formulário de atividade
  e.preventDefault();
  const titulo = $('titulo').value.trim();
  if (!titulo) return;
  const dados = { titulo, cat: $('cat').value, resp: $('resp').value, prazo: $('prazo').value };
  if (editAtiv) {                                        // modo edição: atualiza os campos
    const t = tarefas.find(x => x.id === editAtiv);
    if (t) Object.assign(t, dados);                      // Object.assign copia os campos novos para a atividade
  } else {                                               // modo criação: nova atividade no início da lista
    tarefas.unshift({ id: novoId(), status: 'todo', ...dados });
  }
  resetAtiv(); salvar(); render();
  $('titulo').focus();
});
$('cancela').onclick = resetAtiv;                        // Cancelar edição

/* ===== DESENHAR A TELA ===== */
function renderUsuarios() {                              // lista de usuários + opções do campo "Responsável"
  const ul = $('listaUsuarios'); ul.replaceChildren();
  if (!usuarios.length) ul.appendChild(el('li', 'n', 'Nenhum usuário cadastrado.'));
  usuarios.forEach(u => {
    const li = el('li');
    li.appendChild(el('span', null, u.nome));
    const qtd = tarefas.filter(t => t.resp === u.id).length; // quantas atividades ele tem
    li.appendChild(el('span', 'n', qtd + (qtd === 1 ? ' atividade' : ' atividades')));
    const b1 = el('button', null, 'Editar');   b1.onclick = () => editarUsuario(u.id);
    const b2 = el('button', 'del', 'Excluir'); b2.onclick = () => apagarUsuario(u.id);
    li.append(b1, b2);                                   // append aceita vários elementos de uma vez
    ul.appendChild(li);
  });
  const s = $('resp'), atual = s.value;                  // guarda a escolha atual do select
  s.replaceChildren();
  const o = el('option', null, 'Sem responsável'); o.value = ''; s.appendChild(o);
  usuarios.forEach(u => { const op = el('option', null, u.nome); op.value = u.id; s.appendChild(op); });
  s.value = atual;                                       // restaura a escolha (se ainda existir)
}

function render() {
  renderUsuarios();

  // --- Filtros ---
  const fb = $('filtros'); fb.replaceChildren();
  CATS.forEach(c => {
    const b = el('button', 'chip', c); b.type = 'button';
    b.setAttribute('aria-pressed', c === filtro);        // marca o filtro ativo (o CSS usa isso)
    b.onclick = () => { filtro = c; render(); };
    fb.appendChild(b);
  });
  fb.appendChild(el('span', 'spacer'));
  const lim = el('button', 'link', 'Limpar concluídas'); lim.type = 'button';
  lim.onclick = () => {
    if (!confirm('Excluir todas as atividades concluídas?')) return;
    tarefas = tarefas.filter(t => t.status !== 'done');
    salvar(); render();
  };
  fb.appendChild(lim);

  // --- Quadro ---
  const board = $('board'); board.replaceChildren();
  const vis = tarefas.filter(t => filtro === 'Todas' || t.cat === filtro);
  STATUS.forEach((s, i) => {
    const col = el('section', 'col');
    col.style.setProperty('--c', s.cor);                 // cor da faixa do topo
    const lista = vis.filter(t => t.status === s.k);
    const h = el('h2', null, s.nome); h.appendChild(el('span', null, lista.length));
    col.appendChild(h);
    if (!lista.length) col.appendChild(el('div', 'empty', 'Nenhuma atividade aqui.'));

    lista.forEach(t => {
      const c = el('article', 'card' + (s.k === 'done' ? ' done' : ''));
      c.appendChild(el('p', null, t.titulo));
      const m = el('div', 'meta');
      m.appendChild(el('span', 'tag', t.cat));
      const nome = nomeUsuario(t.resp);                  // responsável (vazio se não houver)
      if (nome) m.appendChild(el('span', 'tag', '👤 ' + nome));
      if (t.prazo) {
        const atrasada = s.k !== 'done' && t.prazo < hoje();
        m.appendChild(el('span', 'tag' + (atrasada ? ' late' : ''), (atrasada ? 'Atrasada: ' : 'Prazo: ') + fmt(t.prazo)));
      }
      c.appendChild(m);

      const a = el('div', 'acts');
      if (i > 0) { const b = el('button', null, '◀ ' + STATUS[i - 1].nome); b.onclick = () => mover(t.id, STATUS[i - 1].k); a.appendChild(b); }
      if (i < 2) { const b = el('button', null, STATUS[i + 1].nome + ' ▶'); b.onclick = () => mover(t.id, STATUS[i + 1].k); a.appendChild(b); }
      const ed = el('button', null, 'Editar');  ed.onclick = () => editarAtiv(t.id);
      const d = el('button', 'del', 'Excluir'); d.onclick = () => apagar(t.id);
      a.append(ed, d);
      c.appendChild(a);
      col.appendChild(c);
    });
    board.appendChild(col);
  });

  // --- Progresso (todas as atividades, sem filtro) ---
  const n = tarefas.length;
  const fe = tarefas.filter(t => t.status === 'done').length;
  const an = tarefas.filter(t => t.status === 'doing').length;
  $('pct').textContent = (n ? Math.round(fe / n * 100) : 0) + '%';
  $('resumo').textContent = fe + ' de ' + n + ' concluídas';
  $('bd').style.width = (n ? fe / n * 100 : 0) + '%';
  $('bg').style.width = (n ? an / n * 100 : 0) + '%';
}

render(); // desenha a tela pela primeira vez

// ===== Estado =====
let session = JSON.parse(sessionStorage.getItem('session') || 'null'); // { userId, username, role }
let products = [];
let cart = new Map(); // productId -> quantidade

const $ = (sel) => document.querySelector(sel);
const money = (v) => Number(v).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// ===== API =====
async function api(path, options = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (session) headers['x-user-id'] = session.userId;
  const res = await fetch(path, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Erro inesperado.');
  return data;
}

let toastTimer;
function toast(msg, isError = false) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.toggle('err', isError);
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 3500);
}

// ===== Login / sessão =====
$('#login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  $('#login-error').textContent = '';
  try {
    const data = await api('/login', {
      method: 'POST',
      body: JSON.stringify({ username: form.get('username'), password: form.get('password') })
    });
    session = { userId: data.userId, username: data.username, role: data.role };
    sessionStorage.setItem('session', JSON.stringify(session));
    e.target.reset();
    startApp();
  } catch (err) {
    $('#login-error').textContent = err.message;
  }
});

$('#logout').addEventListener('click', () => {
  session = null;
  cart.clear();
  sessionStorage.removeItem('session');
  showLogin();
});

function showLogin() {
  $('#app-view').hidden = true;
  $('#login-view').hidden = false;
}

async function startApp() {
  $('#login-view').hidden = true;
  $('#app-view').hidden = false;
  const isAdmin = session.role === 'admin';
  $('#user-label').textContent = `${session.username} (${isAdmin ? 'administrador' : 'operador'})`;
  document.querySelectorAll('.admin-only').forEach((el) => (el.hidden = !isAdmin));
  switchTab('pdv');
  await loadProducts();
  renderCart();
}

// ===== Abas =====
document.querySelectorAll('.tab').forEach((btn) =>
  btn.addEventListener('click', () => switchTab(btn.dataset.tab))
);

function switchTab(name) {
  document.querySelectorAll('.tab').forEach((b) => b.classList.toggle('active', b.dataset.tab === name));
  ['pdv', 'stock', 'report'].forEach((t) => ($(`#tab-${t}`).hidden = t !== name));
  if (name === 'stock') renderStock();
  if (name === 'report') loadReport();
}

// ===== Produtos =====
async function loadProducts() {
  try {
    products = await api('/products');
    renderProducts();
    renderStock();
  } catch (err) {
    handleError(err);
  }
}

function renderProducts() {
  $('#product-grid').innerHTML = products.map((p) => {
    const inCart = cart.get(p.id) || 0;
    const left = p.stock - inCart;
    return `<button class="product" data-id="${p.id}" ${left <= 0 ? 'disabled' : ''}>
      <span class="name">${esc(p.name)}</span>
      <span class="price">${money(p.price)}</span>
      <span class="stock ${left <= 3 ? 'low' : ''}">${left <= 0 ? 'Esgotado' : `${left} em estoque`}</span>
    </button>`;
  }).join('') || '<p class="muted">Nenhum produto cadastrado.</p>';
}

$('#product-grid').addEventListener('click', (e) => {
  const btn = e.target.closest('.product');
  if (btn) changeQty(Number(btn.dataset.id), 1);
});

// ===== Pedido =====
function changeQty(id, delta) {
  const product = products.find((p) => p.id === id);
  if (!product) return;
  const next = (cart.get(id) || 0) + delta;
  if (next <= 0) cart.delete(id);
  else if (next <= product.stock) cart.set(id, next);
  renderCart();
  renderProducts();
}

function renderCart() {
  let total = 0;
  const rows = [...cart].map(([id, qty]) => {
    const p = products.find((x) => x.id === id);
    if (!p) return '';
    total += p.price * qty;
    return `<li>
      <span>${esc(p.name)}</span><strong>${money(p.price * qty)}</strong>
      <div class="qty">
        <button data-id="${id}" data-d="-1" aria-label="Diminuir ${esc(p.name)}">−</button>
        <span>${qty}</span>
        <button data-id="${id}" data-d="1" aria-label="Aumentar ${esc(p.name)}">+</button>
      </div>
    </li>`;
  }).join('');
  $('#cart-list').innerHTML = rows || '<li class="empty">Toque em um produto para adicioná-lo.</li>';
  $('#cart-total').textContent = money(total);
  $('#finish-sale').disabled = cart.size === 0;
}

$('#cart-list').addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-id]');
  if (btn) changeQty(Number(btn.dataset.id), Number(btn.dataset.d));
});

$('#clear-cart').addEventListener('click', () => { cart.clear(); renderCart(); renderProducts(); });

$('#finish-sale').addEventListener('click', async () => {
  const items = [...cart].map(([productId, quantity]) => ({ productId, quantity }));
  try {
    const data = await api('/sales', { method: 'POST', body: JSON.stringify({ items }) });
    toast(`Venda #${data.sale.saleId} registrada: ${money(data.sale.total)}`);
    cart.clear();
    await loadProducts();
    renderCart();
  } catch (err) {
    handleError(err);
    await loadProducts();
  }
});

// ===== Estoque (admin) =====
function renderStock() {
  $('#stock-body').innerHTML = products.map((p) =>
    `<tr><td>${esc(p.name)}</td><td class="num">${money(p.price)}</td><td class="num">${p.stock}</td></tr>`
  ).join('');
}

$('#product-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const f = new FormData(e.target);
  try {
    const data = await api('/products', {
      method: 'POST',
      body: JSON.stringify({ name: f.get('name').trim(), price: f.get('price'), stock: f.get('stock') })
    });
    toast(data.message);
    e.target.reset();
    await loadProducts();
  } catch (err) {
    handleError(err);
  }
});

// ===== Relatório (admin) =====
async function loadReport() {
  try {
    const data = await api('/sales');
    $('#sum-count').textContent = data.totalSalesCount;
    $('#sum-revenue').textContent = money(data.totalRevenue);
    $('#sales-list').innerHTML = [...data.sales].reverse().map((s) => `
      <article class="sale">
        <header>
          <span>Venda #${s.saleId} · ${esc(s.operatorName)}</span>
          <span>${new Date(s.date).toLocaleString('pt-BR')} — ${money(s.total)}</span>
        </header>
        <ul>${s.items.map((i) => `<li>${i.quantity}× ${esc(i.name)} (${money(i.subtotal)})</li>`).join('')}</ul>
      </article>`).join('') || '<p class="muted">Nenhuma venda registrada ainda.</p>';
  } catch (err) {
    handleError(err);
  }
}

// ===== Erros =====
function handleError(err) {
  toast(err.message, true);
  if (/não autenticado/i.test(err.message)) { session = null; sessionStorage.removeItem('session'); showLogin(); }
}

// ===== Início =====
session ? startApp() : showLogin();

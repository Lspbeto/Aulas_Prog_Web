const express = require('express');
const path = require('path');
const app = express();
const PORT = 3000;

// Middleware para interpretar requisições com corpo em JSON
app.use(express.json());

// Serve o front-end (index.html, style.css, app.js) da pasta "public"
app.use(express.static(path.join(__dirname, 'public')));

// ==========================================
// BANCOS DE DADOS EM MEMÓRIA (Simulação)
// ==========================================

// Usuários com diferentes níveis de acesso (admin e operador)
const users = [
    { id: 1, username: 'admin', password: '123', role: 'admin' },
    { id: 2, username: 'operador1', password: '123', role: 'operator' }
];

// Estoque de produtos da lanchonete
let inventory = [
    { id: 1, name: 'X-Burger', price: 15.00, stock: 10 },
    { id: 2, name: 'Batata Frita', price: 8.00, stock: 15 },
    { id: 3, name: 'Refrigerante 350ml', price: 5.00, stock: 20 }
];

// Histórico de vendas realizadas
let sales = [];

// ==========================================
// MIDDLEWARES DE AUTENTICAÇÃO E AUTORIZAÇÃO
// ==========================================

/**
 * Obtém o ID do usuário simulando uma sessão.
 * Aceita o header "x-user-id" (recomendado, funciona em GET) ou "userId" no corpo.
 */
function getUserId(req) {
    const raw = req.headers['x-user-id'] ?? (req.body && req.body.userId);
    return Number(raw);
}

/**
 * Middleware para verificar se o usuário é Administrador
 */
function verifyAdmin(req, res, next) {
    const user = users.find(u => u.id === getUserId(req));

    if (!user) {
        return res.status(401).json({ error: 'Usuário não autenticado ou não encontrado.' });
    }

    if (user.role !== 'admin') {
        return res.status(403).json({ error: 'Acesso negado. Apenas administradores podem realizar esta ação.' });
    }

    req.user = user;
    next();
}

/**
 * Middleware para verificar se o usuário é Operador ou Admin (qualquer funcionário autenticado)
 */
function verifyStaff(req, res, next) {
    const user = users.find(u => u.id === getUserId(req));

    if (!user) {
        return res.status(401).json({ error: 'Usuário não autenticado ou não encontrado.' });
    }

    req.user = user;
    next();
}

// ==========================================
// ROTAS DA APLICAÇÃO
// ==========================================

// 1. Rota de Login (Retorna o ID e a Role para simular sessão)
app.post('/login', (req, res) => {
    const { username, password } = req.body || {};
    const user = users.find(u => u.username === username && u.password === password);

    if (!user) {
        return res.status(401).json({ error: 'Credenciais inválidas.' });
    }

    res.json({
        message: 'Login realizado com sucesso!',
        userId: user.id,
        username: user.username,
        role: user.role
    });
});

// 2. Listar Produtos / Estoque (qualquer usuário autenticado)
app.get('/products', verifyStaff, (req, res) => {
    res.json(inventory);
});

// 3. Adicionar ou Atualizar Produto (APENAS ADMIN)
app.post('/products', verifyAdmin, (req, res) => {
    const { name, price, stock } = req.body;

    if (!name || price === undefined || stock === undefined) {
        return res.status(400).json({ error: 'Preencha nome, preço e quantidade em estoque.' });
    }

    const priceNum = Number(price);
    const stockNum = Number(stock);

    if (!Number.isFinite(priceNum) || priceNum < 0 || !Number.isInteger(stockNum) || stockNum < 0) {
        return res.status(400).json({ error: 'Preço deve ser um número >= 0 e estoque um inteiro >= 0.' });
    }

    // Verifica se o produto já existe para atualizar ou criar novo
    const existingProduct = inventory.find(p => p.name.toLowerCase() === String(name).toLowerCase());

    if (existingProduct) {
        existingProduct.price = priceNum;
        existingProduct.stock += stockNum;
        return res.json({ message: 'Estoque atualizado com sucesso!', product: existingProduct });
    }

    const newProduct = {
        id: inventory.reduce((max, p) => Math.max(max, p.id), 0) + 1,
        name: String(name),
        price: priceNum,
        stock: stockNum
    };

    inventory.push(newProduct);
    res.status(201).json({ message: 'Produto cadastrado com sucesso!', product: newProduct });
});

// 4. Realizar Venda (Operador ou Admin)
app.post('/sales', verifyStaff, (req, res) => {
    const { items } = req.body; // Espera um array de { productId, quantity }

    if (!items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: 'Carrinho de vendas vazio ou formato inválido.' });
    }

    // Valida formato e agrupa itens repetidos (evita vender além do estoque)
    const requested = new Map();
    for (const item of items) {
        const productId = Number(item && item.productId);
        const quantity = Number(item && item.quantity);

        if (!Number.isInteger(productId) || !Number.isInteger(quantity) || quantity <= 0) {
            return res.status(400).json({ error: 'Cada item deve ter productId e quantity (inteiro positivo).' });
        }

        requested.set(productId, (requested.get(productId) || 0) + quantity);
    }

    // Validação de estoque antes de efetivar a venda
    for (const [productId, quantity] of requested) {
        const product = inventory.find(p => p.id === productId);

        if (!product) {
            return res.status(404).json({ error: `Produto com ID ${productId} não encontrado.` });
        }

        if (product.stock < quantity) {
            return res.status(400).json({ error: `Estoque insuficiente para o produto: ${product.name}. Disponível: ${product.stock}` });
        }
    }

    // Efetivando a baixa no estoque e calculando o total
    let totalSalePrice = 0;
    const soldItemsDetails = [];

    for (const [productId, quantity] of requested) {
        const product = inventory.find(p => p.id === productId);
        product.stock -= quantity;

        const subtotal = product.price * quantity;
        totalSalePrice += subtotal;

        soldItemsDetails.push({
            productId: product.id,
            name: product.name,
            quantity,
            unitPrice: product.price,
            subtotal
        });
    }

    // Registrando a venda
    const newSale = {
        saleId: sales.length + 1,
        operatorId: req.user.id,
        operatorName: req.user.username,
        items: soldItemsDetails,
        total: totalSalePrice,
        date: new Date().toISOString()
    };

    sales.push(newSale);

    res.status(201).json({
        message: 'Venda realizada com sucesso!',
        sale: newSale
    });
});

// 5. Visualizar Relatório de Vendas (APENAS ADMIN)
app.get('/sales', verifyAdmin, (req, res) => {
    res.json({
        totalSalesCount: sales.length,
        totalRevenue: sales.reduce((acc, sale) => acc + sale.total, 0),
        sales
    });
});

// ==========================================
// INICIALIZAÇÃO DO SERVIDOR
// ==========================================
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT} (http://localhost:${PORT})`);
});
